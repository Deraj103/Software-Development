﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtNumFootballs = New System.Windows.Forms.TextBox()
        Me.txtNumBasketballs = New System.Windows.Forms.TextBox()
        Me.txtNumVolleyballs = New System.Windows.Forms.TextBox()
        Me.lblTotalItems = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblSubtotalFootballs = New System.Windows.Forms.Label()
        Me.lblSubtotalBasketballs = New System.Windows.Forms.Label()
        Me.lblSubtotalVolleyballs = New System.Windows.Forms.Label()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.lblSalesTax = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.btnCheckout = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 26)
        Me.Label1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(98, 28)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Footballs"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 85)
        Me.Label2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(121, 28)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Basketballs"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 147)
        Me.Label3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 28)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Volleyballs"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 203)
        Me.Label4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(116, 28)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Total items"
        '
        'txtNumFootballs
        '
        Me.txtNumFootballs.Location = New System.Drawing.Point(191, 18)
        Me.txtNumFootballs.Name = "txtNumFootballs"
        Me.txtNumFootballs.Size = New System.Drawing.Size(100, 36)
        Me.txtNumFootballs.TabIndex = 4
        '
        'txtNumBasketballs
        '
        Me.txtNumBasketballs.Location = New System.Drawing.Point(191, 77)
        Me.txtNumBasketballs.Name = "txtNumBasketballs"
        Me.txtNumBasketballs.Size = New System.Drawing.Size(100, 36)
        Me.txtNumBasketballs.TabIndex = 5
        '
        'txtNumVolleyballs
        '
        Me.txtNumVolleyballs.Location = New System.Drawing.Point(191, 139)
        Me.txtNumVolleyballs.Name = "txtNumVolleyballs"
        Me.txtNumVolleyballs.Size = New System.Drawing.Size(100, 36)
        Me.txtNumVolleyballs.TabIndex = 6
        '
        'lblTotalItems
        '
        Me.lblTotalItems.BackColor = System.Drawing.SystemColors.Info
        Me.lblTotalItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalItems.Location = New System.Drawing.Point(191, 203)
        Me.lblTotalItems.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblTotalItems.Name = "lblTotalItems"
        Me.lblTotalItems.Size = New System.Drawing.Size(100, 28)
        Me.lblTotalItems.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(407, 26)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 28)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "$44.95"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(407, 85)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(78, 28)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "$49.95"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(407, 147)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 28)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "$39.95"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(395, 204)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(90, 28)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Subtotal"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(343, 264)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(142, 28)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "Tax @ 5.00%"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(426, 322)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(59, 28)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "Total"
        '
        'lblSubtotalFootballs
        '
        Me.lblSubtotalFootballs.BackColor = System.Drawing.SystemColors.Info
        Me.lblSubtotalFootballs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSubtotalFootballs.Location = New System.Drawing.Point(521, 26)
        Me.lblSubtotalFootballs.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblSubtotalFootballs.Name = "lblSubtotalFootballs"
        Me.lblSubtotalFootballs.Size = New System.Drawing.Size(117, 28)
        Me.lblSubtotalFootballs.TabIndex = 14
        '
        'lblSubtotalBasketballs
        '
        Me.lblSubtotalBasketballs.BackColor = System.Drawing.SystemColors.Info
        Me.lblSubtotalBasketballs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSubtotalBasketballs.Location = New System.Drawing.Point(521, 84)
        Me.lblSubtotalBasketballs.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblSubtotalBasketballs.Name = "lblSubtotalBasketballs"
        Me.lblSubtotalBasketballs.Size = New System.Drawing.Size(117, 28)
        Me.lblSubtotalBasketballs.TabIndex = 15
        '
        'lblSubtotalVolleyballs
        '
        Me.lblSubtotalVolleyballs.BackColor = System.Drawing.SystemColors.Info
        Me.lblSubtotalVolleyballs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSubtotalVolleyballs.Location = New System.Drawing.Point(521, 146)
        Me.lblSubtotalVolleyballs.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblSubtotalVolleyballs.Name = "lblSubtotalVolleyballs"
        Me.lblSubtotalVolleyballs.Size = New System.Drawing.Size(117, 28)
        Me.lblSubtotalVolleyballs.TabIndex = 16
        '
        'lblSubtotal
        '
        Me.lblSubtotal.BackColor = System.Drawing.SystemColors.Info
        Me.lblSubtotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSubtotal.Location = New System.Drawing.Point(521, 202)
        Me.lblSubtotal.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(117, 28)
        Me.lblSubtotal.TabIndex = 17
        '
        'lblSalesTax
        '
        Me.lblSalesTax.BackColor = System.Drawing.SystemColors.Info
        Me.lblSalesTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSalesTax.Location = New System.Drawing.Point(521, 263)
        Me.lblSalesTax.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblSalesTax.Name = "lblSalesTax"
        Me.lblSalesTax.Size = New System.Drawing.Size(117, 28)
        Me.lblSalesTax.TabIndex = 18
        '
        'lblTotal
        '
        Me.lblTotal.BackColor = System.Drawing.SystemColors.Info
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Location = New System.Drawing.Point(521, 322)
        Me.lblTotal.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(117, 28)
        Me.lblTotal.TabIndex = 19
        '
        'btnCheckout
        '
        Me.btnCheckout.Location = New System.Drawing.Point(521, 377)
        Me.btnCheckout.Name = "btnCheckout"
        Me.btnCheckout.Size = New System.Drawing.Size(117, 39)
        Me.btnCheckout.TabIndex = 20
        Me.btnCheckout.Text = "Checkout"
        Me.btnCheckout.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(521, 444)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(117, 39)
        Me.btnExit.TabIndex = 21
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Kristen ITC", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(55, 374)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(307, 80)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Ginormous Sale!" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "While Supplies Last!!"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 28.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(731, 560)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCheckout)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblSalesTax)
        Me.Controls.Add(Me.lblSubtotal)
        Me.Controls.Add(Me.lblSubtotalVolleyballs)
        Me.Controls.Add(Me.lblSubtotalBasketballs)
        Me.Controls.Add(Me.lblSubtotalFootballs)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lblTotalItems)
        Me.Controls.Add(Me.txtNumVolleyballs)
        Me.Controls.Add(Me.txtNumBasketballs)
        Me.Controls.Add(Me.txtNumFootballs)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Arial Unicode MS", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.Text = "Jim Soxx Sports Sales"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtNumFootballs As TextBox
    Friend WithEvents txtNumBasketballs As TextBox
    Friend WithEvents txtNumVolleyballs As TextBox
    Friend WithEvents lblTotalItems As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lblSubtotalFootballs As Label
    Friend WithEvents lblSubtotalBasketballs As Label
    Friend WithEvents lblSubtotalVolleyballs As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents lblSalesTax As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnCheckout As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label5 As Label
End Class
