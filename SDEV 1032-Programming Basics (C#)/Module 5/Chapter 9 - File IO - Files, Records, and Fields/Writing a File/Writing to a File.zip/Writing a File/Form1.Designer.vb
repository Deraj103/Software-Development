﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtFirst = New System.Windows.Forms.TextBox()
        Me.txtLast = New System.Windows.Forms.TextBox()
        Me.txtPayRate = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtMon = New System.Windows.Forms.TextBox()
        Me.txtWed = New System.Windows.Forms.TextBox()
        Me.txtTues = New System.Windows.Forms.TextBox()
        Me.txtThurs = New System.Windows.Forms.TextBox()
        Me.txtFri = New System.Windows.Forms.TextBox()
        Me.btnStoreData = New System.Windows.Forms.Button()
        Me.btnAllDone = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(60, 100)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "First Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(245, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(320, 27)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Enter data for payroll"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(301, 100)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(138, 27)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Last Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(541, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(124, 27)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Pay Rate"
        '
        'txtFirst
        '
        Me.txtFirst.Location = New System.Drawing.Point(65, 143)
        Me.txtFirst.Name = "txtFirst"
        Me.txtFirst.Size = New System.Drawing.Size(229, 34)
        Me.txtFirst.TabIndex = 4
        '
        'txtLast
        '
        Me.txtLast.Location = New System.Drawing.Point(306, 143)
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(229, 34)
        Me.txtLast.TabIndex = 5
        '
        'txtPayRate
        '
        Me.txtPayRate.Location = New System.Drawing.Point(546, 143)
        Me.txtPayRate.Name = "txtPayRate"
        Me.txtPayRate.Size = New System.Drawing.Size(229, 34)
        Me.txtPayRate.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(60, 215)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(166, 27)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Enter Hours"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(60, 258)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 27)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Mon"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(214, 258)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 27)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Tues"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(373, 258)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 27)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Wed"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(526, 258)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 27)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Thurs"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(679, 258)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(54, 27)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "Fri"
        '
        'txtMon
        '
        Me.txtMon.Location = New System.Drawing.Point(65, 288)
        Me.txtMon.Name = "txtMon"
        Me.txtMon.Size = New System.Drawing.Size(85, 34)
        Me.txtMon.TabIndex = 13
        '
        'txtWed
        '
        Me.txtWed.Location = New System.Drawing.Point(219, 288)
        Me.txtWed.Name = "txtWed"
        Me.txtWed.Size = New System.Drawing.Size(85, 34)
        Me.txtWed.TabIndex = 14
        '
        'txtTues
        '
        Me.txtTues.Location = New System.Drawing.Point(378, 288)
        Me.txtTues.Name = "txtTues"
        Me.txtTues.Size = New System.Drawing.Size(85, 34)
        Me.txtTues.TabIndex = 15
        '
        'txtThurs
        '
        Me.txtThurs.Location = New System.Drawing.Point(531, 288)
        Me.txtThurs.Name = "txtThurs"
        Me.txtThurs.Size = New System.Drawing.Size(85, 34)
        Me.txtThurs.TabIndex = 16
        '
        'txtFri
        '
        Me.txtFri.Location = New System.Drawing.Point(684, 288)
        Me.txtFri.Name = "txtFri"
        Me.txtFri.Size = New System.Drawing.Size(85, 34)
        Me.txtFri.TabIndex = 17
        '
        'btnStoreData
        '
        Me.btnStoreData.Location = New System.Drawing.Point(316, 353)
        Me.btnStoreData.Name = "btnStoreData"
        Me.btnStoreData.Size = New System.Drawing.Size(185, 63)
        Me.btnStoreData.TabIndex = 18
        Me.btnStoreData.Text = "Store Data"
        Me.btnStoreData.UseVisualStyleBackColor = True
        '
        'btnAllDone
        '
        Me.btnAllDone.Location = New System.Drawing.Point(316, 483)
        Me.btnAllDone.Name = "btnAllDone"
        Me.btnAllDone.Size = New System.Drawing.Size(185, 65)
        Me.btnAllDone.TabIndex = 19
        Me.btnAllDone.Text = "All Done"
        Me.btnAllDone.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 27.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOrange
        Me.ClientSize = New System.Drawing.Size(843, 585)
        Me.Controls.Add(Me.btnAllDone)
        Me.Controls.Add(Me.btnStoreData)
        Me.Controls.Add(Me.txtFri)
        Me.Controls.Add(Me.txtThurs)
        Me.Controls.Add(Me.txtTues)
        Me.Controls.Add(Me.txtWed)
        Me.Controls.Add(Me.txtMon)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtPayRate)
        Me.Controls.Add(Me.txtLast)
        Me.Controls.Add(Me.txtFirst)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Courier New", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.Name = "Form1"
        Me.Text = "Writing To a File"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtFirst As TextBox
    Friend WithEvents txtLast As TextBox
    Friend WithEvents txtPayRate As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txtMon As TextBox
    Friend WithEvents txtWed As TextBox
    Friend WithEvents txtTues As TextBox
    Friend WithEvents txtThurs As TextBox
    Friend WithEvents txtFri As TextBox
    Friend WithEvents btnStoreData As Button
    Friend WithEvents btnAllDone As Button
End Class
