alert( 'First external JavaScript' )
